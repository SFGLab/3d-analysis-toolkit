#! /usr/bin/env python

import glob
import os
import re
import subprocess
import sys
from fractions import gcd

# import numpy as np

chr_length = {'chr1': 249250621,
              'chr2': 243199373,
              'chr3': 198022430,
              'chr4': 191154276,
              'chr5': 180915260,
              'chr6': 171115067,
              'chr7': 159138663,
              'chr8': 146364022,
              'chr9': 141213431,
              'chr10': 135534747,
              'chr11': 135006516,
              'chr12': 133851895,
              'chr13': 115169878,
              'chr14': 107349540,
              'chr15': 102531392,
              'chr16': 90354753,
              'chr17': 81195210,
              'chr18': 78077248,
              'chr19': 59128983,
              'chr20': 63025520,
              'chr21': 48129895,
              'chr22': 51304566,
              'chrX': 155270560}

keyword_files = {
    'CTCF_loops': '/d/data/chiapet/human_motifs/GM12878.CTCF.clusters_PET4+.with.ConvergentLeftRightWard.motifs.txt',
    'RNAPII_loops': '/d/data/chiapet/human_motifs/GM12878_RNAPII_combine_withLinker.clusters.intra.PET4+.bed',
    'CTCF_singletons': '/d/data/chiapet/human_motifs/GM12878.CTCF.singletons_cluster_PET_2_3.txt',
    'RNAPII_singletons': '/d/data/chiapet/human_motifs/GM12878_RNAPII_combine_withLinker.singleton.intra.bed',
    'merged_anchors': '/d/data/chiapet/human_motifs/GM12878.CTCF.clusters_PET4+.motifs.merged_anchors.simple.txt',
    'segments': '/d/data/chiapet/human_motifs/segment_split_midgaps.txt',
    'CCD': '/d/data/chiapet/GM12878_CCD.txt'
}


def error(msg):
    print("Error! " + msg)
    sys.exit()


# utility function, takes a keyword and tries to return a corresponding file
# eg, for "CTCF" and "CCD" it would return ChIA-PET CTCF loops and CCDs for the default dataset
# for "CTCF_leukemia" it would return ChIA-PET loops for leukemia dataset
# the keywords needs to be specified in 
# return a single filename as string
def get_file_by_keyword(keyword):
    if keyword not in keyword_files:
        print("keyword %s not found!" % keyword)
        return None
    return keyword_files[keyword]


# as get_file_by_keyword(), but accepts list of keywords (comma-separated) and returns list of strings
def get_files_by_keyword(keywords):
    keys = keywords.split(",")
    ret = []
    for k in keys:
        if k not in keyword_files:
            print("keyword %s not found!" % k)
        ret = ret + keyword_files[k].split(",")
    return ret


def get_chromosome_ids():
    chrs = ["chr" + str(i) for i in range(1, 23)]
    chrs.append("chrX")
    return chrs


# single_chr_as_string - if True and 'str' represent whole chromosome return it as a string rather than 1-element list
def parse_genomic_string(str, whole_chr_as_string=False):
    if isinstance(str, list):
        return str

    if str in list(chr_length.keys()):
        if whole_chr_as_string:
            return str
        return [str]
    m = re.match('^(chr.{1,2}):(\d+)-(\d+)$', str)
    if not m:
        return False
    if len(m.groups()) != 3:
        return False
    return [m.group(1), int(m.group(2)), int(m.group(3))]


def stringify_genomic_string(bed, filename_safe=False):
    """returns string representation of a region.
	if 'filename_safe' uses underscores ('_') as a separator. Useful for filenames for saving"""
    if len(bed) >= 6:
        return "%s:%d-%d;%s:%d-%d;cnt=%d" % (bed[0], bed[1], bed[2], bed[0], bed[3], bed[4], bed[5])
    if filename_safe:
        return "%s_%d_%d" % (bed[0], bed[1], bed[2])
    return "%s:%d-%d" % (bed[0], bed[1], bed[2])


def parse_genomic_length(str):
    """parse genomic length (eg. 20kb, 1Mb, 5mb) and returns corresponding value (in bp)"""
    if isinstance(str, int):
        return str

    str = str.lower()
    mult = 1
    suf = str[-2:]
    if suf == "kb" or suf == "mb":
        mult = 1000 if suf == "kb" else 1000000
        return int(str[:-2]) * mult
    if suf == "bp":
        return int(str[:-2])
    return int(str)


def stringify_genomic_length(length):
    if length >= 1e6 and length % 1e6 == 0:
        return str(int(length / 1e6)) + "Mb"
    if length >= 1e3 and length % 1e3 == 0:
        return str(int(length / 1e3)) + "kb"
    return str(int(length))


def detect_chromosome(str, verbose=True, quit_on_failure=False):
    """Detect chromosome id ina a specified string. Useful for example to check which chr file path refer to.
	Returns None on failure, chr id if a single is matched or a list with chr ids if there are more than one"""
    m = re.findall("(chr(?:[\d]{1,2}|X))", str)
    if len(m) == 0:
        if verbose:
            print("could not detect chromosome (%s)" % str)
        if quit_on_failure:
            sys.exit()
        return None
    if len(m) == 1:
        return m[0]
    return m


def detect_resolution(str, quit_on_failure=False, verbose=True):
    """Given a string (eg. a filename) tries to detect the resolution from stringified form (eg. 50kb, 1Mb)"""
    str = str.lower()
    for res in ["kb", "mb"]:
        m = re.search("\d+%s" % res, str)
        if m is not None:
            r = parse_genomic_length(m.group(0))
            if verbose:
                print("resolution %s detected" % stringify_genomic_length(r))
            return r
    if quit_on_failure:
        print("could not detect resolution (%s)" % str)
        sys.exit()
    return None


def detect_resolution_sparse(path, lines=100, verbose=False):
    """Tries to detect the resolution of a sparse heatmap"""
    res = 0
    with open(path) as f:
        for i, line in enumerate(f):
            arr = line.split()
            if len(arr) < 3:
                continue
            # print arr
            vals = list(map(int, arr[0:2]))
            if res == 0:
                res = gcd(vals[0], vals[1])
            else:
                res = gcd(res, vals[0])
                res = gcd(res, vals[1])

            if i >= lines:
                break

    if verbose:
        print("detected resolution: %s" % stringify_genomic_length(res))
    return res


def get_heatmap_size(path):
    """return the size of the .heat heatmap"""
    with open(path) as f:
        return int(f.readline())


def bed_length(bed):
    if isinstance(bed, str):
        bed = parse_genomic_string(bed)
    if len(bed) >= 3:
        return bed[2] - bed[1] + 1
    return 0


def are_regions_identical(a, b):
    if len(a) < 3 or len(b) < 3:
        return False
    return a[0] == b[0] and a[1] == b[1] and a[2] == b[2]


def read_bed(path, region=False, annotations=False):
    """Reads specified bed file, returns list of 3-element lists ([['chr_id', start, end], ...])
	if 'annotations' then loads also 4th column, if present """
    if not os.path.exists(path):
        # self.logger.error("file does not exist (%s)" % path)
        print("file does not exist (%s)" % path)
        return []

    data = []
    with open(path, "r") as file:
        for line in file:
            arr = line.split()
            if len(arr) >= 3:
                start = int(arr[1])
                end = int(arr[2])
                if region and (arr[0] != region[0] or not intervals_overlap(start, end, region[1], region[2])):
                    continue
                if annotations and len(arr) >= 4:
                    data.append([arr[0], start, end, arr[3]])
                else:
                    data.append([arr[0], start, end])
    return data


def read_bedpe(path, region=False):
    data = []
    with open(path, "r") as file:
        for line in file:
            arr = line.split()
            if len(arr) < 6:
                continue
            if region and (arr[0] != region[0] or arr[0] != arr[3]):  # check chromosome
                continue
            start1 = int(arr[1])
            end1 = int(arr[2])
            start2 = int(arr[4])
            end2 = int(arr[5])
            if not region or (
                    interval_contains(region[1], region[2], start1, end1) and interval_contains(region[1], region[2],
                                                                                                start2, end2)):
                row = [arr[0], start1, end1, arr[3], start2, end2]
                if len(arr) >= 7:
                    row.extend(arr[6:])
                data.append(row)
        file.close()
    return data


def write_bed(path, bed):
    with open(path, "w") as f:
        for r in bed:
            f.write('\t'.join([str(rr) for rr in r]) + os.linesep)
        f.close()


def get_regions_from_chr(bed, chr):
    return [b for b in bed if b[0] == chr]


def find_intersecting_regions(bed, region, margin=0):
    return [b for b in bed if b[0] == region[0] and region[1] < b[2] + margin and region[2] + margin > b[1]]


def find_interactions_in_region(region, bedpe, sort_ends=True, margin=0):
    """Finds all interactions from bedpe file anchored at the region.
	'margin' extends region in both directions, so close interactions can be detected as well
	'sort_ends' - if true than sort ends so that [0:3] represent anchor in the region and [3:6] the other end
	'#return_ends' - if true, only returns location of interactions ends, otherwise returns whole rows"""
    if isinstance(bedpe, str):
        bedpe = read_bedpe(bedpe)

    ret = []
    for loop in bedpe:

        # check chromosome
        if loop[0] != region[0] or loop[3] != region[0]:
            continue

        if intervals_overlap(region[1], region[2], loop[1], loop[2], margin):
            ret.append(loop)  # ends already sorted
        elif intervals_overlap(region[1], region[2], loop[4], loop[5], margin):
            if sort_ends:
                tmp = loop[3:6]
                tmp.extend(loop[0:3])
                tmp.extend(loop[6:])
                ret.append(tmp)
            else:
                ret.append(loop)
    return ret


def sort_bed(bed):
    bed.sort(key=lambda b: b[2])
    bed.sort(key=lambda b: b[1])
    bed.sort(key=lambda b: b[0])


# bed.sort(key=lambda b: ' '.join([str(bb) for bb in b]))


def detect_file_format(path):
    """Tries to automatically detect file format by looking at the extension and the first few lines. For example, should recognize 3-column and 4-column bed files.
	Returns detected format (as string) and some additional info (eg. number of columns)"""
    if path and len(path) > 0:
        ext = os.path.splitext(path)[1]

        if ext == ".bw" or ext == ".bigWig":
            return {"format": "bigWig"}

        if ext == ".htr":
            return {"format": "htr"}

        with open(path, "r") as file:
            first = True
            for line in file:

                # some files may have header, so skip the first line
                if first:
                    first = False
                    continue

                arr = line.split()
                if len(arr) == 3:
                    return {"format": "bed", "columns": 3, "subformat": "bed3"}
                if len(arr) == 4 or len(arr) == 5:  # ignore 5th column
                    if is_number(arr[3]):
                        subf = "bed4num"
                    else:
                        subf = "bed4str"
                    return {"format": "bed", "columns": 4, "subformat": subf}
                if len(arr) >= 6:
                    return {"format": "bedpe", "columns": len(arr)}
                break
    return {"format": "unknown"}


def regions_overlap(a, b, margin=0):
    return a[0] == b[0] and intervals_overlap(a[1], a[2], b[1], b[2], margin=0)


def intervals_overlap(x1, x2, y1, y2, margin=0):
    """checks if intervals (x1, x2) and (y1, y2) overlaps"""
    if y2 + margin <= x1 or y1 - margin >= x2:
        return False
    return True


def interval_contains(x1, x2, y1, y2):
    """checks if interval (x1, x2) fully contain interval (y1, y2)"""
    return y1 >= x1 and y2 <= x2


def map_value(val, x1, x2, y1, y2, clip=False):
    """maps value val from interval (x1, x2) to (y1, y2)"""
    x = 1.0 * (val - x1) / (x2 - x1) * (y2 - y1) + y1
    if clip:
        if x < y1:
            x = y1
        if x > y2:
            x = y2
    return x


def clip(val, lower, upper):
    """Clips a value to a (lower, upper) interval"""
    if val < lower:
        return lower
    if val > upper:
        return upper
    return val


def add_suffix(path, suffix):
    """Adds specified suffix to the filename (before the file extension)"""
    if not suffix:
        return path
    arr = os.path.splitext(path)
    return arr[0] + suffix + arr[1]


def change_extension(path, new_ext):
    """Given a filename, changes its extension to specified one."""
    arr = os.path.splitext(path)
    if new_ext[0] != ".":
        new_ext = "." + new_ext
    return arr[0] + new_ext


def make_dir(dir):
    if not os.path.exists(dir):
        os.makedirs(dir)


def find_files(path, ext=False, quit_on_failure=False, verbose=True):
    """Given a path to file, a directory or pattern returns a list of corresponding files
	if regular file path - returns it (as a list) 
	if directory - returns a list of all files inside the directory, possibly with a specified extension 'ext'
	if pattern - returns list of files matching the pattern:
	   - if contains "CHR", then substitute chromosome ids and return those
	   - otherwise use glob()
	'quit_on_failure' can be used to stop the execution when no files were found"""

    files = []
    if os.path.isfile(path):
        files.append(path)
    else:
        if os.path.isdir(path):
            if ext:
                files = glob.glob(os.path.join(path, "*.%s" % ext))  # glob() with extension
            else:
                # glob() everything, filter only files
                files = glob.glob(os.path.join(path, "*"))
                files = [x for x in files if os.path.isfile(x)]
        else:
            if "CHR" in path:
                ids = get_chromosome_ids()
                files = []
                for id in ids:
                    pa = path.replace("CHR", id)
                    if os.path.isfile(pa):
                        files.append(pa)

            # glob pattern may contain "CHR", so we need to check if there are some files matched from CHR pattern
            if len(files) == 0:
                files = glob.glob(path)

        if len(files) == 0 and quit_on_failure:
            error("no files matched")

    if verbose:
        print("found %d file(s)" % len(files))

    # files.sort()
    files = natural_sort(files)
    return files


def sparse_find_number_of_bins(path, res, verbose=False, quick=True):
    """Finds a size of chromosome (in terms of a number of bins).
	If quick, then uses the tail of a file; otherwise read whole file and find max"""
    if not os.path.exists(path):
        print("could not find number of bins, file does not exist")
        sys.exit()

    max_pos = -1
    if quick:
        task = subprocess.Popen(["tail", "-n 5", path], stdout=subprocess.PIPE)
        for line in task.stdout:
            arr = line.split()
            if len(arr) >= 3:
                max_pos = int(arr[1])
        task.wait()
    else:
        with open(path) as f:
            for line in f:
                arr = line.split()
                if len(arr) >= 3:
                    arr = list(map(int, arr[0:2]))
                    for a in arr:
                        if a > max_pos:
                            max_pos = a
            f.close()

    if max_pos < 0:
        error("could not find number of bins, file empty?")

    n_bins = max_pos / res + 1
    print("detected number of bins: %d" % n_bins)
    return n_bins


def htr_find_number_of_bins(path):
    """Finds a size of htr track (in terms of a number of bins for particular loci)."""
    if not os.path.exists(path):
        print("could not find number of bins, file does not exist")
        sys.exit()

    size = None
    with open(path) as f:
        f.readline()  # header
        line = f.readline()
        arr = line.split()
        size = len(arr) - 3
    return size


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


def natural_sort(l):
    """https://stackoverflow.com/questions/4836710/does-python-have-a-built-in-function-for-string-natural-sort"""
    convert = lambda text: int(text) if text.isdigit() else text.lower()
    alphanum_key = lambda key: [convert(c) for c in re.split('([0-9]+)', key)]
    return sorted(l, key=alphanum_key)


def chiapet_loops_iter(path):
    """generator yielding chiapet loops. Accepts filename or list of files"""
    files = [path] if isinstance(path, str) else path
    for file in files:
        with open(file) as f:
            for line in f:
                arr = line.split()
                if len(arr) < 7:
                    continue
                yield [arr[0], int(arr[1]), int(arr[2]), arr[3], int(arr[4]), int(arr[5]), float(arr[6])]


def sparse_heatmap_rows(path):
    """generator yielding sparse heatmap rows"""
    with open(path) as f:
        for line in f:
            arr = line.split()
            if len(arr) < 3:
                continue
            yield [int(arr[0]), int(arr[1]), float(arr[2])]


def chiapet_rows(files):
    """generator yielding sparse heatmap rows.
	paths - either list with files or comma-separated string"""
    if isinstance(files, str):
        files = args.input.split(",")

    for file in files:
        with open(file) as f:
            for line in f:
                arr = line.split()
                if len(arr) < 7:
                    continue
                yield [arr[0], int(arr[1]), int(arr[2]), arr[3], int(arr[4]), int(arr[5]), float(arr[6])]


# create a list of sliding windows of given length and shift
# eg. 10b windows with 1kb shift would give regions [ [0-10000], [1000-11000], [2000-12000], ... ]
# by default shift is equal to size
# 'regions' - list of regions to be 'windowed' (eg. 'chr14', 'chr1:1-1000,chr5:5000-10000')
#             if None than use whole human genome
# return up to max_cnt regions
def create_sliding_windows(size, shift=None, regions=None, max_cnt=None):
    size = parse_genomic_length(size)

    if not shift:
        shift = size
    else:
        shift = parse_genomic_length(shift)

    ret = []  # return list

    regs = []  # list to keep parse regions
    if regions:
        regs = [parse_genomic_string(x, whole_chr_as_string=True) for x in regions.split(",")]
    else:
        regs = get_chromosome_ids()

    for r in regs:

        windows_in_region = create_sliding_windows_for_specified_region(r, size, shift, max_cnt)
        ret.extend(windows_in_region)

        if max_cnt and len(ret) > max_cnt:
            return ret[:max_cnt]
    return ret


# create a list of sliding windows for a particular region
# - starts with the last window that starts to the left of region boundary
# - ends with the first window that reaches (right end) beyond the region 
# region - either chromosome id (eg. "chr5") or ['chr', start, end]
def create_sliding_windows_for_specified_region(region, size, shift, max_cnt=None):
    if isinstance(region, str):
        if region in get_chromosome_ids():
            chr = region
            start = 0
            end = chr_length[chr]
    else:
        chr, start, end = region

    start_pos = start - (start % size)
    ret = []
    while True:

        ret.append([chr, start_pos, start_pos + size])

        if start_pos + size > end:
            break

        start_pos += shift

        if start_pos > end:
            break

        if max_cnt and len(ret) >= max_cnt:
            return ret
    return ret
