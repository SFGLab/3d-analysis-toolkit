import queue
import subprocess
import sys
from multiprocessing import Process
from multiprocessing import Queue


def do_calculation(in_queue: Queue, out_queue: Queue):
    try:
        while True:
            args = in_queue.get(False)
            try:
                subprocess.run(args, shell=True, check=True)
            except subprocess.CalledProcessError as e:
                out_queue.put((e, args))
    except queue.Empty:
        return


cmds_list = [cmd for cmd in open(sys.argv[1])]


input_queue = Queue()
res_queue = Queue()

for el in cmds_list:
    input_queue.put(el)

process_list = []
for i in range(27):
    p = Process(target=do_calculation, args=(input_queue, res_queue))
    p.start()
    process_list.append(p)

for p in process_list:
    p.join()

while not res_queue.empty():
    err = res_queue.get()
    with open('log.txt', 'a') as log_file:
        log_file.write(f"{str(err[0])} {err[1]}")
