import argparse
import os.path
import sys

sys.path.append(os.path.abspath('/d/scripts/lib/genome_lib'))
#from data_science import genome_lib
import genome_lib

parser = argparse.ArgumentParser(description='Converts xyz file(s) to pdb format')
parser.add_argument('-i', '--input',
                    help="input file, directory (all *.txt files are matched) or pattern (matched with glob())",
                    required=True)
args = parser.parse_args()


def readXYZ(fname):
    """Read the points from XYZ file format"""
    pts = [list(map(float, i.strip().split())) for i in open(fname)]
    if len(pts) == 0:
        return []
    if len(pts[0]) < 3:
        pts = pts[1:]
    return pts


def savePointsAsPdb(points, filename, verbose=True):
    """Przyjmuje liste krotek trzy elementowych i zapisuje je do pliku PDB o nazwie filename"""
    atoms = ''
    n = len(points)
    for i in range(n):
        x = points[i][0]
        y = points[i][1]
        try:
            z = points[i][2]
        except IndexError:
            z = 0.0
        atoms += (
            '{0:6}{1:>5}  {2:3}{3:}{4:3} {5:}{6:>4}{7:}   {8:>8.3f}{9:>8.3f}{10:>8.3f}{11:6.2f}{12:6.2f}{13:>12}\n'.format(
                "ATOM", i + 1, 'CA ', ' ', 'ALA', 'A', i + 1, ' ', max(x, -999), max(y, -999), max(z, -999), 0, 0, 'C'))
    connects = ''
    if n != 1:
        connects = 'CONECT    1    2\n'
        for i in range(2, n):
            connects += 'CONECT{:>5}{:>5}{:>5}\n'.format(i, i - 1, i + 1)
        connects += 'CONECT{:>5}{:>5}\n'.format(n, n - 1)
    pdbFileContent = atoms + connects
    open(filename, 'w').write(pdbFileContent)
    if verbose:
        print("File {} saved...".format(filename))
    return filename


# find all input files
files = genome_lib.find_files(args.input, ext="txt", quit_on_failure=True, verbose=True)

for file in files:
    pts = readXYZ(file)
    fout = genome_lib.change_extension(file, "pdb")
    savePointsAsPdb(pts, fout)
