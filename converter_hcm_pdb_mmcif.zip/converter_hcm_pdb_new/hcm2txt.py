import argparse
import os
import sys
#from data_science import genome_lib
import genome_lib

parser = argparse.ArgumentParser(description="Smooths hcm file(s) using 3dnome tool. \n \
    Examples: \n \
    py hcm2txt.py  -i structures/ -m smooth -v 10000 \n \
    py hcm2txt.py -i structures/ -m flat -v 3 \n \
    ", formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('-i', '--input',
                    help="input file, directory (all *.hcm files are matched) or pattern (matched with glob())",
                    required=True)
parser.add_argument('-m', '--mode', help="mode", choices=["smooth", "flatten"], required=True)
parser.add_argument('-v', '--value', help="desired resolution (for smooth) or level of the structure to be flatten",
                    required=True, type=int)
parser.add_argument('-t', '--tool-path', help="path to the 3dgnome",
                    default="/mnt/raid/ctcf_prediction_anal/converter_hcm_pdb/3dnome")
parser.add_argument('-o', '--output', help="output directory")
args = parser.parse_args()

# find all input files
files = genome_lib.find_files(args.input, ext="hcm", quit_on_failure=True, verbose=True)

for file in files:
    option = "-%s %d" % ("r" if args.mode == "smooth" else "l", args.value)
    cmd = "%s -a %s -i %s %s" % (args.tool_path, args.mode, file, option)
    os.system(cmd)
